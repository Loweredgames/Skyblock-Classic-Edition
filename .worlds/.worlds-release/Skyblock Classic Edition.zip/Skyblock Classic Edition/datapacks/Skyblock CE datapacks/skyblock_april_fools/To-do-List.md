**To Do List April Fool:**
- aggiustare un po il datapack
- aggiungere prossimo pesce d'aprile 2025
- testare tutto
- correzioni delle prestazioni e fix bug vari per April